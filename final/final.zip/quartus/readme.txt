Reset/KEY[0] on the board isn't a hardware reset. It resets the ball
and the VGA output to the intital values.