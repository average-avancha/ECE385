For our first demo attempt we missed 1 point for hardware benchmark speed (111KB/s).
We managed to fix our decrypt function in main.c leading to a hardware benchmark speed of 200KB/s.